// Copyright 2014-2017 Insight Software Consortium.
// Copyright 2004-2009 Roman Yakovenko.
// Distributed under the Boost Software License, Version 1.0.
// See http://www.boost.org/LICENSE_1_0.txt

#ifndef __merge_free_functions_hpp__
#define __merge_free_functions_hpp__

#include <iostream>

/*
namespace n1{

struct s1{};
struct s2{};

template<typename _Facet>
bool has_facet(int i) throw(){
	return false;
}

void do_smth(){
	has_facet<s1>( 12 );
	has_facet<s2>( 12 );
}

}
*/


#endif//__merge_free_functions_hpp__

