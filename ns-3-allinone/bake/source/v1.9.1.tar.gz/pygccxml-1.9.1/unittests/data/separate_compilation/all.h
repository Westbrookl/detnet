#ifndef __all_h_10062009__
#define __all_h_10062009__ 1

#include "data.h"
#include "base.h"
#include "derived.h"

#endif//__all_h_10062009__
