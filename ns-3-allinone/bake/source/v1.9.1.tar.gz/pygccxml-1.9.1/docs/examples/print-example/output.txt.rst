======
Output
======

.. literalinclude:: ./output.txt
   :language: text
