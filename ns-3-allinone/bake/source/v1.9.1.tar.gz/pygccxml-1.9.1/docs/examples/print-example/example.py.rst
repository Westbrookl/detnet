=========================
Python API usage example
=========================

.. literalinclude:: example.py
   :language: python
   :lines: 5-

