===============
C++ header file
===============

.. literalinclude:: example.hpp
   :language: c++
   :lines: 5-
