======================
GCC-XML generated file
======================

.. literalinclude:: ./example.hpp.xml
   :language: xml
