======================
Print all declarations
======================

This example prints all declarations found in :doc:`example.hpp <example.hpp>`
file.

For every class, it prints it's base and derived classes.

The example consists from few files:

.. toctree::
   :maxdepth: 1

   example.hpp.rst
   example.hpp.xml.rst
   example.py.rst
   output.txt.rst
